import React, { useState } from 'react';
import { Alert, ScrollView, StyleSheet, View } from 'react-native';
import BottomTabs from '../../components/BottomTabs';
import Header from '../../components/Header';
import HorizontalMenu from '../../components/HorizontalMenu';
import { TOP_MENU } from '../../constants/data';
import Explore from './explore';
import Holdings from './holdings';
import OrdersScreen from './orders';
import PositionsScreen from './positions';
import WatchlistsScreen from './watchlist';

const userAvatar = require('../../assets/images/user.jpg');

export default function TabsLayout() {
  const [selected, setSelected] = useState('Explore');

  const renderContent = () => {
    switch (selected) {
      case 'Explore':
        return <Explore />;
      case 'Holdings':
        return <Holdings />;
      case 'Positions':
        return <PositionsScreen />;
      case 'Orders':
        return <OrdersScreen />;
      case 'Watchlist':
        return <WatchlistsScreen />;
      default:
        return null;
    }
  };

  const handleBellPress = () => {
    Alert.alert('Notifications', 'You tapped the bell!');
  };

  const handleSearchPress = () => {
    Alert.alert('Search', 'You tapped the search icon!');
  };

  return (
    <View style={styles.container}>
      <Header
        username="User"
        avatar={userAvatar}
        onBellPress={handleBellPress}
        onSearchPress={handleSearchPress}
      />

      <HorizontalMenu
        items={TOP_MENU}
        selected={selected}
        onSelect={setSelected}
      />

      <ScrollView contentContainerStyle={styles.scrollContent}>
        {renderContent()}
      </ScrollView>

      <BottomTabs />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  scrollContent: { paddingBottom: 90 },
});
