import React from 'react';
import { ScrollView, View ,Text, StyleSheet} from 'react-native';
import FeatureCards from '../../components/FeatureCards';
import Banner from '../../components/Banner';
import ProductTools from '../../components/ProductTools';
import TopMovers from '../../components/TopMovers';
import { TOOLS, TOP_MOVERS, QUICK_ACTIONS } from '../../constants/data';
import QuickActions from '../../components/QuickActions';

export default function Explore() {
  return (
    
    <ScrollView>
      <FeatureCards />
      <QuickActions actions={QUICK_ACTIONS} />
      <Banner />
      <ProductTools tools={TOOLS} />
      <TopMovers stocks={TOP_MOVERS} />
    </ScrollView>
    
  );
}