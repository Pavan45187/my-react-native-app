import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList, SafeAreaView, Image } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

// --- Data Structure ---
const GraphPositive = require('../../assets/images/graph1.jpg');

interface HoldingItem {
  id: string;
  name: string;
  shares: string;
  current: string;
  invested: string;
  change: string;
  isPositive: boolean;
  graphImage: any; // Local image import
}

const HOLDINGS_DATA: HoldingItem[] = [
  {
    id: '1',
    name: 'Tata Motors Passenger',
    shares: '2 shares',
    current: '₹799.50',
    invested: '₹806.00',
    change: '-0.52%',
    isPositive: false,
    graphImage: GraphPositive,
  },
  {
    id: '2',
    name: 'Artemis Medicare',
    shares: '1 share',
    current: '₹242.50',
    invested: '₹306.93',
    change: '-1.37%',
    isPositive: false,
    graphImage: GraphPositive,
  },
  {
    id: '3',
    name: 'INOX Wind',
    shares: '1 share',
    current: '₹859.50',
    invested: '₹806.00',
    change: '+0.66%',
    isPositive: true,
    graphImage: GraphPositive,
  },
  {
    id: '4',
    name: 'Likhitha Infra',
    shares: '1 share',
    current: '₹242.50',
    invested: '₹306.93',
    change: '-1.37%',
    isPositive: false,
    graphImage: GraphPositive,
  },
  {
    id: '5',
    name: 'Gold 24K Physical',
    shares: '1.5147 g',
    current: '₹20,160.19',
    invested: '₹19,937.28',
    change: '+1.11%',
    isPositive: true,
    graphImage: GraphPositive,
  },
  {
    id: '6',
    name: 'Silver 999 Physical',
    shares: '0.2402 g',
    current: '₹42.94',
    invested: '₹43.72',
    change: '-0.23%',
    isPositive: false,
    graphImage: GraphPositive,
  },
];

// --- Holding Card Component ---
const HoldingCard = ({ item }: { item: HoldingItem }) => {
  const colorStyle = item.isPositive ? styles.green : styles.red;

  return (
    <TouchableOpacity style={styles.card}>
      {/* LEFT: Name and Shares */}
      <View style={styles.cardLeft}>
        <Text style={styles.stockName}>{item.name}</Text>
        <Text style={styles.shares}>{item.shares}</Text>
      </View>

      {/* CENTER: Graph Image */}
      <View style={styles.cardCenter}>
        <Image source={item.graphImage} style={styles.graphImage} resizeMode="stretch" />
      </View>

      {/* RIGHT: Price and Invested */}
      <View style={styles.cardRight}>
        <Text style={[styles.current, colorStyle]}>{item.current}</Text>
        <Text style={styles.investedSmall}>({item.invested})</Text>
      </View>
    </TouchableOpacity>
  );
};

// --- Main Holdings Screen ---
export default function HoldingsScreen() {
  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.container}>
        {/* Summary Card */}
        <View style={styles.summaryCard}>
          <View style={styles.row}>
            <Text style={styles.title}>HOLDINGS ({HOLDINGS_DATA.length})</Text>
            <View style={styles.icons}>
              <Ionicons name="eye-outline" size={22} color="#000" style={styles.icon} />
              <Ionicons name="stats-chart-outline" size={22} color="#000" />
            </View>
          </View>

          <Text style={styles.amount}>₹1,418.42</Text>

          {/* Returns section */}
          <View style={styles.returnsContainer}>
            <Text style={styles.returnLabel}>1D returns</Text>
            <Text style={styles.positive}>+7.36 (0.52%)</Text>
          </View>

          <View style={styles.returnsContainer}>
            <Text style={styles.returnLabel}>Total returns</Text>
            <Text style={styles.negative}>-₹132.41 (-8.55%)</Text>
          </View>
        </View>

        {/* Holdings List */}
        <FlatList
          data={HOLDINGS_DATA}
          renderItem={({ item }) => <HoldingCard item={item} />}
          keyExtractor={(item) => item.id}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingBottom: 100 }}
        />
      </View>
    </SafeAreaView>
  );
}

// --- Styles ---
const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: '#fff' },
  container: { flex: 1, paddingHorizontal: 15 },
  summaryCard: {
    backgroundColor: '#f8f9fa',
    borderRadius: 12,
    padding: 16,
    marginTop: 10,
    marginBottom: 15,
  },
  row: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  icons: { flexDirection: 'row', gap: 12 },
  title: { fontSize: 16, fontWeight: '600', color: '#000' },
  icon: { marginRight: 10 },
  amount: { fontSize: 26, fontWeight: 'bold', marginTop: 10, color: '#000' },
  returnsContainer: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 5 },
  returnLabel: { fontSize: 14, color: '#777' },
  positive: { color: 'green', fontSize: 14, fontWeight: '500' },
  negative: { color: 'red', fontSize: 14, fontWeight: '500' },

  card: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 12,
    marginBottom: 10,
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  cardLeft: { flex: 1 },
  stockName: { fontSize: 15, fontWeight: '500', color: '#000' },
  shares: { fontSize: 13, color: '#666', marginTop: 2 },
  cardCenter: { flex: 1, alignItems: 'center' },
  graphImage: { width: 80, height: 35 },
  cardRight: { alignItems: 'flex-end' },
  current: { fontSize: 15, fontWeight: '600' },
  investedSmall: { fontSize: 12, color: '#777' },
  green: { color: 'green' },
  red: { color: 'red' },
});
