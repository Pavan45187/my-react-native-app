import React from 'react';
import { View, Text, StyleSheet, SafeAreaView, Image, Dimensions } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

// IMPORTANT: Assuming your illustration is located in the assets folder.
// You must replace this path with the correct path to your image file 
// (e.g., '../../assets/illustrations/empty_box_illustration.png').
const EMPTY_STATE_IMAGE = require('../../assets/images/positions.png'); 

// --- Illustration Component: Using the Image Asset ---
const EmptyPositionsIllustration = () => {
  return (
    <View style={styles.illustrationContainer}>
      
      {/* Box Illustration Image */}
      <Image 
        source={EMPTY_STATE_IMAGE}
        style={styles.illustrationImage}
        resizeMode="contain"
      />

      {/* Main Text */}
      <Text style={styles.mainText}>
        No open equity intraday or MTF position
      </Text>
    </View>
  );
};

// --- Main Positions Screen ---
export default function PositionsScreen() {
  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.container}>
        <EmptyPositionsIllustration />
      </View>
    </SafeAreaView>
  );
}

// --- Styles ---
const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#fff',
  },
  container: { 
    flex: 1, 
    backgroundColor: '#fff', 
    paddingHorizontal: 16,
    // Center content vertically and horizontally
    justifyContent: 'center',
    alignItems: 'center',
  },

  // --- Illustration Styles ---
  illustrationContainer: {
    alignItems: 'center',
    marginBottom: 100, // Keep content slightly above vertical center
  },
  
  illustrationImage: {
    width: 200, // Adjust size to match the original design's width
    height: 150, // Adjust height as necessary
    marginBottom: 30,
  },
  
  mainText: {
    marginTop: 10,
    fontSize: 15,
    color: '#333',
    textAlign: 'center',
    fontWeight: '600',
    lineHeight: 24,
  },
});
