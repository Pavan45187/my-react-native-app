//app/auth/_layout.tsx
import { Stack } from 'expo-router';
import React from 'react';

// Layout for all screens in the 'app/auth' group
export default function AuthLayout() {
  return (
    <Stack>
      <Stack.Screen 
        name="index" // This refers to app/auth/login.tsx
        options={{ 
          headerShown: false, // Hide the navigation bar for the login screen
        }} 
      />
    </Stack>
  );
}