//app/auth/index.tsx
import React, { useState } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity, Dimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

const { width } = Dimensions.get('window');

// NOTE: This screen does not use Expo Router's default layout, 
// so we'll ensure it looks good with a custom gradient-like background.

export default function LoginScreen() {
    const [phoneNumber, setPhoneNumber] = useState('');

    const handleGetOTP = () => {
        // TODO: Implement phone number validation and API call to send OTP
        console.log('Requesting OTP for:', phoneNumber);
        // router.push('/auth/otp-verification'); // Example next step
    };

    return (
        <SafeAreaView style={styles.safeArea}>
            <View style={styles.container}>
                {/* Visual Header/Gradient Placeholder */}
                <View style={styles.visualHeader} />

                {/* Content Section */}
                <View style={styles.content}>
                    <Text style={styles.title}>Log in / Sign up</Text>
                    <Text style={styles.subtitle}>Please enter your phone number.</Text>

                    {/* Phone Number Input */}
                    <View style={styles.inputContainer}>
                        <Text style={styles.countryCode}>+91</Text>
                        <TextInput
                            style={styles.input}
                            placeholder="Enter your phone number"
                            keyboardType="phone-pad"
                            onChangeText={setPhoneNumber}
                            value={phoneNumber}
                            maxLength={10} 
                        />
                    </View>

                    {/* Spacer to push button/terms to the bottom */}
                    <View style={{ flex: 1 }} />
                      
                    {/* Terms and Conditions */}
                    <Text style={styles.termsText}>
                        By proceeding, you agree with Credora's 
                        <Text style={styles.linkText}> terms and conditions</Text> and{' '}
                        <Text style={styles.linkText}>privacy policy</Text>.
                    </Text>

                    {/* GET OTP Button */}
                    <TouchableOpacity 
                        style={[styles.otpButton, { opacity: phoneNumber.length === 10 ? 1 : 0.6 }]}
                        onPress={handleGetOTP}
                        disabled={phoneNumber.length !== 10}
                    >
                        <Text style={styles.buttonText}>GET OTP</Text>
                    </TouchableOpacity>
                </View>
                <View style={styles.visualFooter} />
            </View>
        </SafeAreaView>
    );
}

const styles = StyleSheet.create({
    safeArea: {
        flex: 1,
        backgroundColor: 'white', // Light background for the whole page
    },
    container: {
        flex: 1,
        position: 'relative',

    },
    // Simulating the light green gradient/visual blur from the design
    visualHeader: {
        position: 'absolute',
        top: 0,
        left: 0,
        width: width,
        height: width * 0.6, // Top portion
        backgroundColor: '#d2efcf', // Light green tint
        borderBottomLeftRadius: 50,
        borderBottomRightRadius: 230,
        opacity: 0.5,
    },

  visualFooter: {
  position: 'absolute',
  bottom: 0,
  left: 0,
  width: width,
  height: width * 0.6, // adjust as needed
  backgroundColor: '#ebf0f0',
  borderTopLeftRadius: 180,
  borderTopRightRadius: 30,
  opacity: 0.7,
  zIndex: -1, // ensures content sits above the footer
},

    content: {
        flex: 1,
        paddingHorizontal: 25,
        paddingTop: 80, // Space below the status bar/visual header
    },
    title: {
        fontFamily: 'Poppins',
        fontSize: 30,
        fontWeight: '700',
        color: '#000000',
        marginBottom: 10,
    },
    subtitle: {
        fontFamily: 'Poppins',
        fontSize: 16,
        color: '#000000',
        fontWeight: 400,
        marginBottom: 30,
    },
    inputContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        height: 59,
        borderWidth: 0,
        borderRadius: 12,
        paddingHorizontal: 15,
        backgroundColor: '#e1e0e0c0',
        shadowRadius: 0,
        
    },
    countryCode: {
        fontSize: 16,
        fontWeight: '500',
        marginRight: 10,
        color: '#333',
    },
    input: {
        flex: 1,
        fontSize: 16,
        color: '#333',
        backgroundColor:  '#e1e0e01b',
        borderWidth: 0,
        borderRadius: 12,
         
    },
    termsText: {
        fontSize: 16,
        fontFamily: 'Poppins',
        fontWeight: 400,
        color: '#000000',
        textAlign: 'center',
        marginBottom: 15,
        lineHeight: 18,
    },
    linkText: {
        fontWeight: 700,
        color: '#000000',
        fontSize: 16,
    },
    otpButton: {
        width: '100%',  
        paddingVertical: 15,
        borderRadius: 12,
        backgroundColor: '#2EC4B6', // Teal/Green color from onboarding
        marginBottom: 20, // Space for the home indicator bar
        shadowColor: '#4CD9A3',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.3,
        shadowRadius: 5,
        elevation: 10,
    },
    buttonText: {
        color: '#ffffff',
        fontSize: 22,
        fontWeight: 500,
        textAlign: 'center',
    },
});