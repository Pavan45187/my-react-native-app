import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function PledgeGold() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Pledge My Gold</Text>
      <Text style={styles.text}>
        This is the Pledge My Gold feature page. Add feature details here.
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  title: { fontSize: 22, fontWeight: '700' },
  text: { marginTop: 10, textAlign: 'center' },
});
