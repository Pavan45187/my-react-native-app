import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput, FlatList } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';

// Mock Data - In a real app, this would come from an API or Hook
const INDICES = [
  { id: '1', name: 'NIFTY 50', price: '22,096.75', change: '+31.10', percent: '0.14%', up: true },
  { id: '2', name: 'BANK NIFTY', price: '46,594.10', change: '-212.40', percent: '0.45%', up: false },
];

const CATEGORIES = [
  { name: 'F&O', icon: ' analytics-outline' },
  { name: 'Intraday', icon: 'timer-outline' },
  { name: 'IPO', icon: 'business-outline' },
  { name: 'All Stocks', icon: 'list-outline' },
];

export default function StocksPage() {
  const router = useRouter();

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()}>
          <Ionicons name="chevron-back" size={28} color="#111" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Explore Stocks</Text>
        <TouchableOpacity>
          <Ionicons name="person-circle-outline" size={30} color="#111" />
        </TouchableOpacity>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
        {/* Search Bar */}
        <View style={styles.searchSection}>
          <View style={styles.searchBar}>
            <Ionicons name="search" size={20} color="#888" />
            <TextInput 
              placeholder="Search stocks, companies..." 
              style={styles.searchInput}
              placeholderTextColor="#999"
            />
          </View>
        </View>

        {/* Market Indices */}
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.indicesContainer}>
          {INDICES.map((item) => (
            <View key={item.id} style={styles.indexCard}>
              <Text style={styles.indexName}>{item.name}</Text>
              <Text style={styles.indexPrice}>₹{item.price}</Text>
              <Text style={[styles.indexChange, { color: item.up ? '#00C853' : '#FF3D00' }]}>
                {item.change} ({item.percent})
              </Text>
            </View>
          ))}
        </ScrollView>

        {/* Categories Grid */}
        <View style={styles.categoryContainer}>
          {CATEGORIES.map((cat, i) => (
            <TouchableOpacity key={i} style={styles.categoryItem}>
              <View style={styles.iconCircle}>
                <Ionicons name={cat.icon as any} size={22} color="#0d6efd" />
              </View>
              <Text style={styles.categoryText}>{cat.name}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Section Header */}
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Most Bought on Credora</Text>
          <TouchableOpacity><Text style={styles.seeAll}>View All</Text></TouchableOpacity>
        </View>

        {/* Stock List (Simplified) */}
        {[1, 2, 3].map((_, i) => (
          <TouchableOpacity key={i} style={styles.stockRow}>
            <View style={styles.stockLeft}>
              <View style={styles.stockIcon} />
              <View>
                <Text style={styles.stockName}>{i === 0 ? 'Reliance' : i === 1 ? 'TATA Motors' : 'Zomato'}</Text>
                <Text style={styles.stockSymbol}>{i === 0 ? 'RELIANCE' : i === 1 ? 'TATAMOTORS' : 'ZOMATO'}</Text>
              </View>
            </View>
            <View style={styles.stockRight}>
              <Text style={styles.currentPrice}>₹2,450.00</Text>
              <Text style={styles.priceChange}>+1.20%</Text>
            </View>
          </TouchableOpacity>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff', paddingTop: 60 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 20, marginBottom: 20 },
  headerTitle: { fontSize: 20, fontWeight: '700', color: '#111' },
  scrollContent: { paddingBottom: 100 },
  searchSection: { paddingHorizontal: 20, marginBottom: 20 },
  searchBar: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#F5F7F9', padding: 12, borderRadius: 12, borderWidth: 1, borderColor: '#EEE' },
  searchInput: { marginLeft: 10, flex: 1, fontSize: 16 },
  indicesContainer: { paddingLeft: 20, marginBottom: 25 },
  indexCard: { width: 150, padding: 15, backgroundColor: '#fff', borderRadius: 12, borderWidth: 1, borderColor: '#EEE', marginRight: 15 },
  indexName: { fontSize: 12, color: '#666', fontWeight: '600' },
  indexPrice: { fontSize: 16, fontWeight: 'bold', marginVertical: 4 },
  indexChange: { fontSize: 12, fontWeight: '600' },
  categoryContainer: { flexDirection: 'row', justifyContent: 'space-around', paddingHorizontal: 10, marginBottom: 30 },
  categoryItem: { alignItems: 'center' },
  iconCircle: { width: 50, height: 50, borderRadius: 25, backgroundColor: '#EBF3FF', justifyContent: 'center', alignItems: 'center', marginBottom: 8 },
  categoryText: { fontSize: 12, color: '#444', fontWeight: '500' },
  sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', paddingHorizontal: 20, marginBottom: 15 },
  sectionTitle: { fontSize: 18, fontWeight: 'bold' },
  seeAll: { color: '#0d6efd', fontWeight: '600' },
  stockRow: { flexDirection: 'row', justifyContent: 'space-between', paddingHorizontal: 20, paddingVertical: 15, borderBottomWidth: 0.5, borderBottomColor: '#EEE' },
  stockLeft: { flexDirection: 'row', alignItems: 'center' },
  stockIcon: { width: 40, height: 40, borderRadius: 8, backgroundColor: '#F0F0F0', marginRight: 12 },
  stockName: { fontSize: 16, fontWeight: '600' },
  stockSymbol: { fontSize: 12, color: '#888' },
  stockRight: { alignItems: 'flex-end' },
  currentPrice: { fontSize: 16, fontWeight: 'bold' },
  priceChange: { fontSize: 12, color: '#00C853', fontWeight: '600' },
});