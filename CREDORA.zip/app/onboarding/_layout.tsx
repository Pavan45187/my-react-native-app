// app/onboarding/_layout.tsx

import { Stack } from 'expo-router';
import React from 'react';

// Layout for all screens in the 'app/onboarding' group
export default function OnboardingLayout() {
  return (
    <Stack>
      <Stack.Screen 
        name="index" // This refers to app/onboarding/index.tsx
        options={{ 
          headerShown: false, // Hides the navigation bar
        }} 
      />
    </Stack>
  );
}