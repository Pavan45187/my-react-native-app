// app/onboarding/index.tsx

import React, { useState, useRef } from "react";
import { FlatList, View, Dimensions, ViewToken } from "react-native";
import OnboardingItem from "../../components/onboardingItem";
import { slides } from "../../constants/onboardingData";
import { useRouter } from "expo-router";
import { useKeepAwake } from "expo-keep-awake";
// import { useRouter } from 'expo-router'; // If using Expo Router for navigation
import AsyncStorage from "@react-native-async-storage/async-storage";

const { width } = Dimensions.get("window");

export default function OnboardingFlow() {
  useKeepAwake();
  const [currentIndex, setCurrentIndex] = useState(0);
  const flatListRef = useRef<FlatList>(null);
  const router = useRouter();

  const viewabilityConfig = {
    viewAreaCoveragePercentThreshold: 50,
  };

  const handleViewableItemsChanged = useRef(
    ({ viewableItems }: { viewableItems: ViewToken[] }) => {
      if (viewableItems.length > 0 && viewableItems[0].index !== null) {
        setCurrentIndex(viewableItems[0].index);
      }
    }
  ).current;

  const scrollToNext = async () => {
    if (currentIndex < slides.length - 1) {
      flatListRef.current?.scrollToIndex({ index: currentIndex + 1 });
    } else {
      try {
        console.log("✅ Saving onboarding status...");
        await AsyncStorage.setItem("hasOnboarded", "true");

        const check = await AsyncStorage.getItem("hasOnboarded");
        console.log("Saved flag:", check); // should log "true"

        router.replace("/auth"); // use replace() so you can’t go back to onboarding
        console.log("Navigating to auth...");
      } catch (error) {
        console.error("Error setting onboarding complete:", error);
      }
    }
  };
  const skipOnboarding = () => {
    router.push("/auth");
  };

  return (
    <View style={{ flex: 1 }}>
      <FlatList
        ref={flatListRef}
        data={slides}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item, index }) => (
          <View style={{ width: width }}>
            <OnboardingItem
              {...item}
              totalSlides={slides.length}
              currentIndex={index}
              onButtonPress={scrollToNext}
              onSkipPress={skipOnboarding}
            />
          </View>
        )}
        onViewableItemsChanged={handleViewableItemsChanged}
        viewabilityConfig={viewabilityConfig}
      />
    </View>
  );
}