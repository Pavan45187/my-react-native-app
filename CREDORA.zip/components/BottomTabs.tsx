import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Platform } from 'react-native';
import { useRouter, usePathname } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';

// Mapping the tab labels to the specific routes in your /app folder
const tabs = [
  { name: 'Home', path: '/(tabs)', icon: 'home-outline', activeIcon: 'home' },
  { name: 'Stocks', path: '/feature/stocks', icon: 'trending-up-outline', activeIcon: 'trending-up' },
  { name: 'F&O', path: '/feature/options', icon: 'analytics-outline', activeIcon: 'analytics' },
  { name: 'Mutual Funds', path: '/feature/mutualfunds', icon: 'pie-chart-outline', activeIcon: 'pie-chart' },
  { name: 'Metals', path: '/feature/commodity', icon: 'gold-outline', activeIcon: 'gold' },
];

export default function BottomTabs() {
  const router = useRouter();
  const pathname = usePathname();

  return (
    <View style={styles.container}>
      {tabs.map((tab, i) => {
        // This checks if the current path matches the tab's path
        const isActive = pathname === tab.path;

        return (
          <TouchableOpacity 
            key={i} 
            style={styles.tab} 
            activeOpacity={0.6}
            onPress={() => router.push(tab.path as any)}
          >
            <Ionicons 
              name={(isActive ? tab.activeIcon : tab.icon) as any} 
              size={22} 
              color={isActive ? '#0d6efd' : '#666'} 
            />
            <Text style={[
              styles.text, 
              isActive && styles.activeText
            ]}>
              {tab.name}
            </Text>
            
            {/* Visual underline indicator for the active tab */}
            {isActive && <View style={styles.activeIndicator} />}
          </TouchableOpacity>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    borderTopWidth: 1,
    borderTopColor: '#eee',
    paddingTop: 12,
    // Extra bottom padding for iOS "Home Indicator" area
    paddingBottom: Platform.OS === 'ios' ? 30 : 12, 
    backgroundColor: '#fff',
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    // Soft shadow for depth
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -3 },
    shadowOpacity: 0.05,
    shadowRadius: 5,
    elevation: 8,
  },
  tab: { 
    alignItems: 'center',
    flex: 1,
  },
  text: { 
    fontSize: 10, 
    color: '#666', 
    marginTop: 4,
    fontWeight: '500'
  },
  activeText: { 
    color: '#0d6efd', 
    fontWeight: '700' 
  },
  activeIndicator: {
    position: 'absolute',
    top: -12, // Align with the top border of the container
    width: 20,
    height: 3,
    backgroundColor: '#0d6efd',
    borderBottomLeftRadius: 3,
    borderBottomRightRadius: 3,
  }
});